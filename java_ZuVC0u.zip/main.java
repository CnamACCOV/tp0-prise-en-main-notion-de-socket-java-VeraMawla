package AccovTP

public class main {

    public static void main(String[] args) {
        // The rest of the program
    }
    
}